Icon made by Freepik from www.flaticon.com
"# latin_dictionary_browser_extension" 
